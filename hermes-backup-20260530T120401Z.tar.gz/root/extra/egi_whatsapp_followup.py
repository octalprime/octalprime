#!/usr/bin/env python3
import json, re, time, urllib.request, os

TRACKER = '/root/egi_whatsapp_leads.json'
LOG = os.path.expanduser('~/.hermes/logs/gateway.log')
FOLLOWUPS = {
    'Martabak Kaka Since 1923': "Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website sederhana untuk Martabak Kaka?\n\nKonsepnya bisa berisi profil, menu, lokasi, galeri, dan tombol WhatsApp agar calon pelanggan mudah cek info dari satu link.",
    'Dua Pintu Coffee Roastery': "Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website sederhana untuk Dua Pintu Coffee Roastery?\n\nKonsepnya bisa berisi profil, menu/produk, galeri, lokasi, dan tombol WhatsApp agar calon pelanggan mudah cek info dari satu link.",
    'Nasi Kapau Uni Lis': "Halo Uni/Tim Nasi Kapau Uni Lis, izin konfirmasi pesan saya kemarin. Apakah berkenan kalau saya kirim contoh konsep website sederhana untuk Nasi Kapau Uni Lis?\n\nKonsepnya bisa berisi profil, menu, lokasi, galeri, dan tombol WhatsApp agar pelanggan mudah cek info dari satu link."
}

def post_send(chat_id, message):
    data = json.dumps({'chatId': chat_id, 'message': message}).encode()
    req = urllib.request.Request('http://127.0.0.1:3000/send', data=data, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.status, r.read().decode()

def recent_log_text():
    try:
        with open(LOG, 'r', errors='ignore') as f:
            # Read last ~300KB
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 300000))
            return f.read()
    except Exception:
        return ''

def main():
    try:
        tracker = json.load(open(TRACKER))
    except Exception as e:
        print(f'Follow-up skipped: tracker not readable: {e}')
        return
    log = recent_log_text()
    sent = []
    skipped = []
    for lead in tracker.get('leads', []):
        if lead.get('status') not in ('message_sent', 'intro_sent'):
            skipped.append((lead.get('business'), 'status_not_due'))
            continue
        if lead.get('reply_received'):
            skipped.append((lead.get('business'), 'tracker_reply_received'))
            continue
        chat_id = lead.get('chatId')
        business = lead.get('business')
        # Conservative inbound detection: if recent gateway log contains this lead chatId as an incoming/from field, skip.
        # If logs do not expose chatId, this won't trigger; Egi can manually mark reply_received in tracker if needed.
        inbound_patterns = [f'from={chat_id}', f'from: {chat_id}', f'"from":"{chat_id}"', f'"sender":"{chat_id}"']
        if chat_id and any(p in log for p in inbound_patterns):
            lead['reply_received'] = True
            lead['status'] = 'replied'
            skipped.append((business, 'reply_seen_in_log'))
            continue
        msg = FOLLOWUPS.get(business)
        if not msg or not chat_id:
            skipped.append((business, 'missing_message_or_chatid'))
            continue
        try:
            status, body = post_send(chat_id, msg)
            lead['status'] = 'follow_up_sent'
            lead['follow_up_sent_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
            lead['follow_up_http_status'] = status
            sent.append(business)
            time.sleep(2)
        except Exception as e:
            lead['follow_up_error'] = repr(e)
            skipped.append((business, 'send_error'))
    tracker['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    json.dump(tracker, open(TRACKER, 'w'), indent=2, ensure_ascii=False)
    if sent:
        print('Follow-up WhatsApp terkirim ke: ' + ', '.join(sent))
    if skipped:
        print('Dilewati: ' + '; '.join(f'{b} ({r})' for b, r in skipped if b))
    if not sent and not skipped:
        print('Tidak ada lead yang perlu follow-up.')

if __name__ == '__main__':
    main()
