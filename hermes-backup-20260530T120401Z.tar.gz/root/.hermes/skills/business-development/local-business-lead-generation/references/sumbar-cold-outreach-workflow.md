# Sumatera Barat Cold Outreach Workflow Notes

Session-derived workflow for website-development lead generation in Sumatera Barat.

## Practical lead sources

- OpenStreetMap / Overpass is useful when search results are thin: look for tourism/amenity businesses with public `phone` or `contact:phone` tags and no `website` / `contact:website` tag.
- If `overpass-api.de` rejects or rate-limits a request, retry with a different public Overpass endpoint such as `https://overpass.kumi.systems/api/interpreter` using GET `?data=...` and a normal User-Agent.
- Keep Overpass queries narrow: hotels/guest houses, restaurants, cafes first. Region-wide `phone` queries are likely to timeout.

## Candidate categories that pitched well

Prioritize leads where a website has an obvious revenue/usefulness path:

1. Penginapan / guest house / homestay: rooms, facilities, gallery, Google Maps, WhatsApp booking.
2. Kuliner khas / legacy food brands: menu, story, location, opening hours, WhatsApp/order.
3. Cafe / roastery: brand story, menu, beans/products, gallery, location, WhatsApp/reseller inquiries.

## Verification language

Do not say “tidak punya website” unless strongly verified. Safer phrasing:

> Dari data yang saya cek, saya belum menemukan website resmi yang menampilkan ...

This sounds professional and avoids overclaiming.

## Outreach framing

For cold pitches, avoid opening with “saya jasa pembuatan website.” Instead, lead with a specific gap and business outcome:

- calon pelanggan bisa lihat info lengkap dari Google
- menu/kamar/fasilitas/lokasi lebih rapi
- tombol WhatsApp untuk booking/order
- brand story terlihat lebih profesional

## Batch output pattern

For each lead, return:

- Nama bisnis + kota/area
- Jenis bisnis
- Lokasi
- Kontak publik if visible
- Website status, phrased cautiously
- Why potential: 2–3 bullets
- Specific website idea
- Pitch message
- Follow-up 1

Also include a generic last follow-up:

> Halo kak, saya follow-up terakhir ya. Kalau saat ini belum prioritas tidak apa-apa. Saya hanya ingin menawarkan konsep website sederhana yang fokus ke hasil: info bisnis lebih rapi, mudah ditemukan di Google, dan pelanggan bisa langsung klik WhatsApp. Kalau nanti butuh, saya siap bantu kirim contoh tampilannya.
