# OSM / Overpass for Local Business Leads

Use this reference when lead generation needs businesses in a region that have public contact details but no obvious website.

## Why it helps

OpenStreetMap often has structured tags such as `name`, `phone`, `tourism`, `amenity`, `shop`, `addr:*`, and sometimes `website`. A useful lead signal is: business has `phone`/`contact:phone` and a commercial category, but lacks `website`/`contact:website`.

## Area lookup pattern

1. Use Nominatim to find the OSM relation for the region.
2. Convert relation ID to Overpass area ID by adding `3600000000`.
   - Example from the session: Sumatera Barat relation `2390841` → area `3602390841`.

## Focused Overpass query pattern

Keep queries narrow to avoid timeouts. Start with high-intent categories:

```overpass
[out:json][timeout:50];
area(3602390841)->.a;
(
  nwr["tourism"~"hotel|guest_house|hostel|chalet"]["phone"](area.a);
  nwr["tourism"~"hotel|guest_house|hostel|chalet"]["contact:phone"](area.a);
  nwr["amenity"="restaurant"]["phone"](area.a);
  nwr["amenity"="restaurant"]["contact:phone"](area.a);
);
out tags center 100;
```

Then filter results locally:

- Require `name`.
- Require public `phone` or `contact:phone`.
- Keep commercial categories: `tourism`, `amenity`, `shop`, `craft`, `office`.
- Exclude records with `website` or `contact:website`.
- Search `"<business name>" website` afterward to avoid false positives.

## Query strategy notes

- Large region-wide `nwr["phone"]` queries can timeout. Narrow by category first.
- If a search API returns malformed/empty data, retry with another provider/query or directly fetch a lightweight search results page; the lesson is retry/fallback, not that the tool is unusable.
- Phrase website absence cautiously: “belum terlihat website resmi dari data yang dicek”.

## Good follow-up validation

Search the candidate business name plus:

- `website`
- city name
- `Instagram`
- `Facebook`
- `WhatsApp`
- industry keyword, e.g. `restaurant`, `homestay`, `catering`, `tour`
