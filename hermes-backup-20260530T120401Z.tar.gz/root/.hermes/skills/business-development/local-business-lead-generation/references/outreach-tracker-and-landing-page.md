# Outreach Tracker + Landing Page Ops

Reusable workflow for website-development lead outreach when sending from the user's WhatsApp account.

## Structured tracker

Keep the operational JSON tracker as the source of truth, then export a human-readable tracker alongside it:

- `schema.json` — columns, status meanings, and owner/rules metadata.
- `leads_export.json` — normalized/enriched lead rows.
- `leads_export.csv` — Google Sheets/Excel-friendly export.
- `README.md` — small dashboard: total leads, registered WhatsApp count, valid sends, active leads, invalid/held leads.

Recommended columns:

- `business`
- `city`
- `niche`
- `phone`
- `chatId`
- `whatsapp_registered`
- `status`
- `sent_ok`
- `sent_at`
- `message_id`
- `reply_received`
- `last_message_type`
- `follow_up_due_hours`
- `follow_up_message`
- `source`
- `pitch_message`
- `notes`

Common statuses:

- `pending_review` — found but not contacted yet.
- `message_sent` — intro/pitch sent to a registered WhatsApp number.
- `follow_up_sent` — approved follow-up sent after delay.
- `replied` — lead replied; handle manually/contextually.
- `send_failed_unregistered` — number failed WhatsApp registration check; do not follow up.

## Landing page for outreach

For early validation, create a lightweight personal landing page as “Egi — Web Developer” rather than using Lunos Dev before market interest is proven.

Good sections:

1. Hero: “Saya Egi, web developer” and one clear value proposition.
2. Service cards: profile usaha, katalog layanan/produk, galeri/testimoni, Maps, WhatsApp CTA, SEO lokal dasar.
3. Process: understand business → structure page → launch/revise.
4. Starter package: simple landing page for local business.
5. CTA: “Minta konsep website” / “Kirim nama bisnis”.

Do not mention the user's brand name if the current outreach strategy says to introduce as a personal web developer first.

## Public access gotcha

A page served at `http://127.0.0.1:<port>` is only accessible from the agent/server itself. Before sharing with the user or using it in WhatsApp pitches, expose it via one of:

- A real domain/subdomain and hosting.
- Cloudflare Tunnel quick URL (`cloudflared tunnel --url http://127.0.0.1:<port> --no-autoupdate`) for temporary review.
- Another tunnel provider.

LocalTunnel may show an interstitial asking visitors to enter the tunnel host IP. That is poor for prospect-facing links. Prefer Cloudflare Tunnel for temporary review, and a stable domain for real outreach.

## WhatsApp message branding gotcha

When using Hermes WhatsApp self-chat bridge for outreach, disable the default Hermes header/prefix before sending prospect messages:

```bash
hermes config set whatsapp.reply_prefix ""
hermes gateway restart
```

Verify the config contains:

```yaml
whatsapp:
  reply_prefix: ''
```

Without this, WhatsApp messages may include a visible header like “⚕ Hermes Agent” above the outreach copy, which looks unprofessional to prospects.
