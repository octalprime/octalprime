# WhatsApp Outreach Ops for Local Website Leads

Use this reference when the user has connected WhatsApp (or another personal messaging account) and asks the agent to continue lead outreach directly.

## Safety posture

- Treat the user's WhatsApp as a personal account. Do not let the assistant process or reply to every incoming DM/group by default.
- Before sending or auto-following-up, configure the platform so only approached leads can be processed:
  - `whatsapp.dm_policy = allowlist`
  - `whatsapp.allow_from = [<approached lead JIDs>]`
  - `whatsapp.group_policy = disabled` unless the user explicitly wants group handling
- Apply/restart the gateway after changing these settings.
- Keep a tracker file/list with each contacted lead: business name, public contact, chat ID/JID, message status, sent timestamp, reply status, last message type, follow-up message, source, and next follow-up due time. When useful for the user, export this tracker to CSV/Markdown/JSON so it can be reviewed in Google Sheets or sent as a dashboard.
- Do not save one-off lead numbers to persistent memory; keep them in task-local tracking files or session notes.
- If the outreach is sent from the user's personal WhatsApp account, remove any platform/bot prefix from outgoing messages (for Hermes WhatsApp bridge, set `whatsapp.reply_prefix: ''` and restart the gateway). The recipient should see only the outreach text, not headers such as `⚕ Hermes Agent`.

## Outreach sequence

1. Verify the account/bridge is connected.
2. Start with a very small batch (for example 3-5 contacts) to avoid spam behavior and to learn which copy works.
3. Personalize each message with the business type and observed opportunity.
4. Introduce the user exactly as instructed. If the user says not to use the brand yet, say only something like: `Saya Egi, web developer`.
5. Include the user's portfolio/credibility link in every initial cold pitch when one has been provided, unless the user explicitly says to omit it for that lead. For Egi's current outreach, use `https://egi-webdev.pages.dev/` in the first message.
6. Use a soft CTA: offer to send a simple concept/mockup/structure first, without forcing an order.
7. Track each send result and message ID/status.
8. Schedule a conservative no-response follow-up after the user-approved interval (commonly 24-48 hours).
9. When inbound messages arrive, only reply if the sender is in the approached-lead allowlist and the message is relevant to the offer. Otherwise stay silent or report to the user.

## Operational pattern used in Hermes WhatsApp outreach

- Prefer phone/WhatsApp numbers shown on Google Maps/business profiles when available, then cross-check with the business' public site/social snippets. Do not rely on a random directory number if Google Maps suggests a different current contact.
- Normalize Indonesian public WhatsApp/phone numbers before sending: strip spaces, dashes, and parentheses; convert leading `0` to `62`; then build the JID as `<62number>@s.whatsapp.net` for tracker/allowlist use.
- Verify the normalized JID is registered on WhatsApp before sending. Use the local bridge registration check if available: `POST http://127.0.0.1:<bridge_port>/exists` with JSON `{"chatId":"<jid>"}` or `{"phone":"<number>"}`. Only send when it returns `exists: true`; if `exists: false`, mark/skip the lead as `send_failed_unregistered` or `not_whatsapp_registered` and do not schedule follow-up.
- If the generic `send_message` resolver cannot address a WhatsApp JID directly, use the local WhatsApp bridge HTTP API that the adapter uses: `POST http://127.0.0.1:<bridge_port>/send` with JSON `{"chatId":"<jid>","message":"<text>"}`. Treat HTTP 200 plus a returned `messageId` as send proof only after the registration check passed.
- Immediately after a successful send, upsert the lead in a task-local tracker with: business, public contact, JID, WhatsApp registration check result, message ID/status, sent timestamp, reply status, last message type, follow-up due hours, follow-up copy, and source. For ongoing campaigns, also generate a reviewable export (`leads_export.csv`, `leads_export.json`, and/or `README.md`) with inferred city/niche, active-valid leads, and skipped/unregistered leads.
- Add the approached lead JID to `whatsapp.allow_from` using `hermes config set whatsapp.allow_from '[...]'`, keep `whatsapp.dm_policy=allowlist` and `whatsapp.group_policy=disabled`, then restart/apply the gateway so replies from that lead are processed while unrelated personal chats remain ignored.
- Ensure outreach text is delivered without gateway branding. In Hermes WhatsApp self-chat mode, configure `whatsapp.reply_prefix: ''` (or `WHATSAPP_REPLY_PREFIX=''`) and restart the gateway/bridge before the next pitch or follow-up. Verify by checking the config or bridge environment; do not rely on prompt wording alone because the bridge can prepend the prefix after the agent composes the message.
- When one follow-up script handles multiple leads, include a per-lead due-time check (`sent_at + follow_up_due_hours`) so an earlier scheduled job does not follow up newer leads before their 24-hour window.
- Format recurring cron/watchdog reports for Telegram as concise sections: `Terkirim`, `Dilewati` grouped by reason/count, and `Perlu perhatian` for actionable exceptions. Avoid long semicolon-separated lists of every skipped lead; they are hard to scan in chat.
- If the user says they already replied manually or asks not to follow up a specific client, immediately update the tracker for that lead instead of merely acknowledging. Mark fields such as `reply_received: true`, `status: manual_replied_by_user` (or a user-specific variant like `manual_replied_by_egi`), `do_not_follow_up: true`, and a short `manual_reply_note`. Future follow-up jobs/scripts should check `do_not_follow_up` before sending.
- For leads that only expose Instagram or landline numbers, do not invent a WhatsApp contact. Either use a DM-specific workflow if available, or hold the lead until a public WhatsApp/mobile number is verified.

## Pre-outreach credibility asset

When the user wants to validate demand before using a formal agency/brand name, create a small personal landing page first (for example “Egi — Web Developer”) and use that link in later pitches or after a positive reply. Keep the copy personal, not agency-branded, and verify all WhatsApp links before publishing.

- Start from `templates/personal-web-developer-landing.html`.
- Replace `{{PERSON_NAME}}`, `{{INITIAL}}`, `{{WHATSAPP_NUMBER}}`, and `{{YEAR}}`.
- Do not publish with a placeholder WhatsApp number such as `6280000000000`.
- Keep the page focused on local-business outcomes: profile, catalog, gallery, Maps, testimonials/FAQ, and WhatsApp CTA.
- Preview in a browser and check desktop/mobile readability before sending the link to leads.

## Example first-contact copy

```text
Halo kak, izin kenalan. Saya Egi, web developer.

Saya lihat bisnis kakak punya potensi bagus kalau dibuatkan website sederhana, supaya calon pelanggan bisa cek profil, layanan/produk, galeri, lokasi, dan langsung klik WhatsApp dari satu link yang rapi.

Kalau berkenan, saya bisa kirim contoh konsep singkat yang cocok untuk bisnis kakak. Tidak harus langsung order, cukup lihat dulu apakah cocok.
```

## Example 24-hour follow-up

```text
Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website sederhana untuk bisnis kakak?

Konsepnya bisa berisi profil, layanan/produk, galeri, lokasi, dan tombol WhatsApp agar calon pelanggan mudah cek info dari satu link.
```

## Pitfalls

- Do not send broad, identical blasts from WhatsApp; personalize and pace messages.
- Do not auto-reply to unrelated personal chats on the user's account.
- Do not mention a brand name that the user intentionally wants to hold back during early validation.
- Do not present the follow-up as pressure; frame it as a light confirmation and offer to show a concept first.
