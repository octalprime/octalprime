---
name: local-business-lead-generation
description: Find and qualify local businesses that may need website development or digital presence services, then produce a concise outreach-ready lead.
---

# Local Business Lead Generation

Use this skill when the user asks to find potential clients/leads for website development, landing pages, SEO, online ordering, booking systems, or other digital services in a specific city/region/industry.

## Goal

Return a small number of actionable, credible leads — usually 1 if the user asks for “satu potensi” — with enough context to contact them and pitch a specific website value proposition.

## Workflow

1. **Interpret the market and geography**
   - Identify the requested location, service being sold, and likely lead categories.
   - For website development, prioritize businesses where a website directly increases revenue: restaurants, cafes, homestays, hotels, tours, clinics, schools/courses, event venues, workshops, local product brands, and professional services.

2. **Search for businesses with digital presence gaps**
   - Look for businesses that have phone/social/listing visibility but no obvious official website.
   - Useful signals:
     - Google/social/listing results dominate instead of an official domain.
     - Business has Instagram/Facebook/WhatsApp but no website.
     - Business appears on third-party menu, review, hotel, marketplace, or directory sites.
     - OSM/business-directory tags include `phone` but not `website`.

## Fallback discovery techniques when normal search is thin**
   - Use search queries like:
     - `"<city>" "WhatsApp" "Instagram" "<industry>"`
     - `"<business name>" website`
     - `site:instagram.com "<city>" "WhatsApp" "<industry>"`
     - `site:facebook.com "<city>" "WhatsApp" "<industry>"`
   - Overpass can be useful for finding businesses with phone numbers but no website tag. See `references/osm-overpass-local-leads.md`.
   - For Sumatera Barat cold outreach patterns and sample framing, see `references/sumbar-cold-outreach-workflow.md`.
   - For WhatsApp execution after the user binds their account, use `references/whatsapp-outreach-ops.md`: keep replies scoped to approached leads, maintain a tracker, use a WhatsApp allowlist, schedule conservative follow-ups, normalize Indonesian numbers to WhatsApp JIDs, and guard shared follow-up scripts so newer leads are not followed up before their approved window.
   - For the combined tracker + outreach landing-page workflow, use `references/outreach-tracker-and-landing-page.md`: export the lead tracker to CSV/JSON/README dashboard, build a personal “Egi — Web Developer” landing page before using the Lunos Dev brand, expose local pages through a public tunnel/domain before sharing, and disable any Hermes WhatsApp reply prefix/header before prospect messages.
   - If one search provider returns an empty/invalid result, retry with a different query/provider or use a direct lightweight search endpoint rather than concluding there are no leads. Search-result snippets from alternate engines can reveal public phone/WhatsApp numbers, but verify the number is plausibly tied to the target business before outreach.IDs, and guard shared follow-up scripts so newer leads are not followed up before their approved window.
  - For the combined tracker + outreach landing-page workflow, use `references/outreach-tracker-and-landing-page.md`: export the lead tracker to CSV/JSON/README dashboard, build a personal “Egi — Web Developer” landing page before using the Lunos Dev brand, expose local pages through a public tunnel/domain before sharing, and disable any Hermes WhatsApp reply prefix/header before prospect messages.
  - If one search provider returns an empty/invalid result, retry with a different query/provider or use a direct lightweight search endpoint rather than concluding there are no leads. Search-result snippets from alternate engines can reveal public phone/WhatsApp numbers, but verify the number is plausibly tied to the target business before outreach.
   - When Overpass endpoint requests fail, try an alternate public endpoint (for example Kumi Systems) and keep the query category-narrow to avoid timeouts; capture the retry pattern, not the transient failure.

4. **Qualify the lead**
   - Verify at least two of: business name, location, category, phone/social/listing, absence of obvious official website.
   - Avoid overstating certainty. Phrase as “tidak terlihat ada website resmi dari data yang dicek” rather than “tidak punya website” unless verified.
   - Do not expose private or masked contact data if the tool output masks it; use only visible public contact details.

5. **Execute controlled outreach when the user asks you to send**
   - Use a small batch first; do not mass-send or reuse generic copy across many leads.
   - Track each contacted lead with status, timestamp, channel ID/number, last message type, and follow-up due time.
   - When sending from the user's WhatsApp/account, introduce the user exactly as requested. If the user says to hold a brand name until there is more interest, use the personal intro (for example, “Saya Egi, web developer”) and do not mention the brand in the first contact.
   - Vary the greeting/opening across cold WhatsApp pitches so they do not look templated/spammy. Use natural business-specific openings such as “Selamat pagi/siang Tim <bisnis>”, “Halo Tim <bisnis>”, or “Halo kak, salam kenal”, then include a specific public observation before the offer.
   - If the user has provided a portfolio/credibility link for cold outreach, treat it as mandatory in every initial pitch unless they explicitly exclude it for that lead. Do not leave it out merely because the copy is already personalized.
   - Scope auto-replies/follow-up to numbers the assistant has approached first. Do not answer unrelated personal chats.
   - If the user manually handles a lead or says not to follow up, update the tracker immediately (`reply_received`, `do_not_follow_up`, and a manual-reply status/note) so scheduled follow-up automation skips that lead.
   - For scheduled job/report output, keep Telegram reports grouped and count-based instead of dumping long semicolon-separated skip lists. Show sent leads, skip counts by reason, and only name items that need attention.
   - For no-response follow-ups, schedule a light confirmation after the agreed delay (for example 24 hours) asking whether they are interested in seeing a simple concept/mockup.

6. **Return an outreach-ready answer**
   - Keep it practical and concise, especially for Telegram.
   - Include:
     - Business name
     - Category
     - Location
     - Public contact/social if available
     - Why they are a good fit
     - Specific website offer/features
     - Short pitch message the user can copy
   - For Indonesian users, respond in Indonesian unless they ask otherwise.

## Output pattern

```markdown
## Potensi Lead: <Nama Bisnis> — <Kota>

**Jenis:** <kategori>
**Lokasi:** <alamat/kota>
**Kontak:** <nomor/sosial/listing jika publik>
**Website:** <status hati-hati: “belum terlihat website resmi”>

**Kenapa potensial:**
- <reason 1>
- <reason 2>
- <reason 3>

**Ide penawaran:**
<landing page / katalog / booking / WhatsApp / SEO lokal / menu / galeri>

**Pitch singkat:**
> Halo kak, saya <nama> ...
```

## Pitfalls

- Do not treat transient search/tool failures as evidence that no leads exist; retry with alternate queries or data sources.
- Do not claim a business definitively lacks a website unless you checked enough results to support it.
- Do not dump many weak leads when the user asked for one potential client; pick the strongest and make it actionable.
- Do not persist one-off lead names, phone numbers, or session results to memory; those become stale. Capture reusable search/qualification workflow in this skill instead.
- Do not send WhatsApp outreach from a newly bound personal account while the platform adapter is open to all DMs/groups. First restrict processing to an allowlist of approached leads and disable irrelevant groups, then restart/apply the gateway config.
- Do not use the user's brand name in outreach if they asked to wait until market interest is validated; the intro wording is part of the offer positioning.
- Do not share `127.0.0.1`/localhost landing-page URLs with the user or prospects; those only work from the agent/server. Expose the page through a public tunnel or stable hosting first.
- Do not let Hermes/bridge branding leak into prospect WhatsApp messages. If using the Hermes WhatsApp bridge in self-chat mode, set `whatsapp.reply_prefix: ''` and restart the gateway before sending outreach.
