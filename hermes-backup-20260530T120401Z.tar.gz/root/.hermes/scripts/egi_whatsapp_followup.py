#!/usr/bin/env python3
import json, re, time, urllib.request, os
from datetime import datetime, timedelta, timezone

TRACKER = '/root/egi_whatsapp_leads.json'
LOG = os.path.expanduser('~/.hermes/logs/gateway.log')
DRY_RUN = os.getenv('DRY_RUN') == '1'
FOLLOWUPS = {
    'Martabak Kaka Since 1923': "Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website sederhana untuk Martabak Kaka?\n\nKonsepnya bisa berisi profil, menu, lokasi, galeri, dan tombol WhatsApp agar calon pelanggan mudah cek info dari satu link.",
    'Dua Pintu Coffee Roastery': "Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website sederhana untuk Dua Pintu Coffee Roastery?\n\nKonsepnya bisa berisi profil, menu/produk, galeri, lokasi, dan tombol WhatsApp agar calon pelanggan mudah cek info dari satu link.",
    'Nasi Kapau Uni Lis': "Halo Uni/Tim Nasi Kapau Uni Lis, izin konfirmasi pesan saya kemarin. Apakah berkenan kalau saya kirim contoh konsep website sederhana untuk Nasi Kapau Uni Lis?\n\nKonsepnya bisa berisi profil, menu, lokasi, galeri, dan tombol WhatsApp agar pelanggan mudah cek info dari satu link.",
    'Kontraktor Renovasi Desain Interior Medan (@renovasidesaininterior)': "Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website portfolio sederhana untuk jasa renovasi/desain interior kakak?\n\nKonsepnya bisa berisi profil usaha, layanan, galeri proyek, testimoni, area layanan, dan tombol WhatsApp agar calon klien mudah konsultasi dari satu link.",
    'Wondery Tour / CV Wondery Agita Wisata': "Halo kak, izin konfirmasi pesan saya kemarin. Apakah kakak tertarik kalau saya kirim contoh konsep website landing page untuk Wondery Tour?\n\nKonsepnya bisa berisi pilihan paket tour, itinerary contoh, galeri trip, testimoni, FAQ, dan tombol konsultasi WhatsApp agar calon customer lebih mudah cek info dari satu link."
}

def post_send(chat_id, message):
    data = json.dumps({'chatId': chat_id, 'message': message}).encode()
    req = urllib.request.Request('http://127.0.0.1:3000/send', data=data, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.status, r.read().decode()

def recent_log_text():
    try:
        with open(LOG, 'r', errors='ignore') as f:
            # Read last ~300KB
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 300000))
            return f.read()
    except Exception:
        return ''

def mask_phone(phone_or_chat_id):
    digits = re.sub(r'\D+', '', phone_or_chat_id or '')
    if not digits:
        return '-'
    if len(digits) <= 6:
        return digits[:2] + '***'
    return digits[:4] + '***' + digits[-3:]

def skip_label(reason):
    return {
        'not_due_yet': 'belum 24 jam',
        'status_not_due': 'status tidak perlu follow-up',
        'tracker_reply_received': 'sudah ada balasan/ditangani',
        'reply_seen_in_log': 'balasan terdeteksi',
        'missing_message_or_chatid': 'pesan follow-up/chatId belum lengkap',
        'send_error': 'gagal kirim',
    }.get(reason, reason)

def print_report(sent, skipped):
    print('## Laporan Follow-up WhatsApp')
    if DRY_RUN:
        print('_Mode cek format: tidak mengirim pesan._')
    print()

    if sent:
        print(f'**Terkirim ({len(sent)}):**')
        for item in sent:
            print(f"- {item['business']} ({mask_phone(item.get('phone') or item.get('chatId'))})")
    else:
        print('**Terkirim:** tidak ada')

    counts = {}
    for item in skipped:
        counts[item['reason']] = counts.get(item['reason'], 0) + 1
    if counts:
        print('\n**Dilewati:**')
        for reason, count in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
            print(f'- {skip_label(reason)}: {count}')

    important_reasons = {'send_error', 'missing_message_or_chatid', 'reply_seen_in_log'}
    important = [item for item in skipped if item['reason'] in important_reasons]
    if important:
        print('\n**Perlu perhatian:**')
        for item in important[:8]:
            print(f"- {item['business']}: {skip_label(item['reason'])}")

    print('\nRingkas: job aktif; follow-up hanya dikirim untuk lead yang sudah lewat 24 jam, belum dibalas, dan tidak ditandai do-not-follow-up.')

def main():
    try:
        tracker = json.load(open(TRACKER))
    except Exception as e:
        print(f'Follow-up skipped: tracker not readable: {e}')
        return
    log = recent_log_text()
    sent = []
    skipped = []
    for lead in tracker.get('leads', []):
        business = lead.get('business')
        phone = lead.get('phone')
        chat_id = lead.get('chatId')

        if lead.get('do_not_follow_up') or lead.get('status') in ('manual_replied_by_egi', 'replied', 'follow_up_sent'):
            skipped.append({'business': business, 'reason': 'tracker_reply_received', 'phone': phone, 'chatId': chat_id})
            continue
        if lead.get('status') not in ('message_sent', 'intro_sent'):
            skipped.append({'business': business, 'reason': 'status_not_due', 'phone': phone, 'chatId': chat_id})
            continue
        if lead.get('reply_received'):
            skipped.append({'business': business, 'reason': 'tracker_reply_received', 'phone': phone, 'chatId': chat_id})
            continue

        sent_at = lead.get('sent_at')
        due_hours = int(lead.get('follow_up_due_hours') or tracker.get('rules', {}).get('follow_up_after_hours_if_no_reply') or 24)
        try:
            sent_dt = datetime.strptime(sent_at, '%Y-%m-%dT%H:%M:%S%z')
            if datetime.now(timezone.utc) < sent_dt + timedelta(hours=due_hours):
                skipped.append({'business': business, 'reason': 'not_due_yet', 'phone': phone, 'chatId': chat_id})
                continue
        except Exception:
            # If sent_at is missing/malformed, fall through and use the scheduler timing.
            pass

        # Conservative inbound detection: if recent gateway log contains this lead chatId as an incoming/from field, skip.
        # If logs do not expose chatId, this won't trigger; Egi can manually mark reply_received in tracker if needed.
        inbound_patterns = [f'from={chat_id}', f'from: {chat_id}', f'"from":"{chat_id}"', f'"sender":"{chat_id}"']
        if chat_id and any(p in log for p in inbound_patterns):
            lead['reply_received'] = True
            lead['status'] = 'replied'
            skipped.append({'business': business, 'reason': 'reply_seen_in_log', 'phone': phone, 'chatId': chat_id})
            continue

        msg = lead.get('follow_up_message') or FOLLOWUPS.get(business)
        if not msg or not chat_id:
            skipped.append({'business': business, 'reason': 'missing_message_or_chatid', 'phone': phone, 'chatId': chat_id})
            continue
        try:
            if DRY_RUN:
                status = 0
            else:
                status, body = post_send(chat_id, msg)
                lead['status'] = 'follow_up_sent'
                lead['follow_up_sent_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
                lead['follow_up_http_status'] = status
                time.sleep(2)
            sent.append({'business': business, 'phone': phone, 'chatId': chat_id})
        except Exception as e:
            lead['follow_up_error'] = repr(e)
            skipped.append({'business': business, 'reason': 'send_error', 'phone': phone, 'chatId': chat_id})

    if not DRY_RUN:
        tracker['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
        json.dump(tracker, open(TRACKER, 'w'), indent=2, ensure_ascii=False)
    print_report(sent, skipped)

if __name__ == '__main__':
    main()
