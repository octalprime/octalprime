#!/usr/bin/env bash
set -euo pipefail
hermes gateway restart
