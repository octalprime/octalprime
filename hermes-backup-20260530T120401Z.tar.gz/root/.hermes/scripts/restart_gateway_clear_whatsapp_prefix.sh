#!/usr/bin/env bash
set -euo pipefail
hermes gateway restart >/root/.hermes/logs/restart_gateway_clear_whatsapp_prefix.log 2>&1 || true
# Verify after restart that config still disables WhatsApp prefix.
python - <<'PY'
import yaml, pathlib
p=pathlib.Path.home()/'.hermes/config.yaml'
c=yaml.safe_load(p.read_text()) or {}
assert (c.get('whatsapp') or {}).get('reply_prefix') == ''
PY
