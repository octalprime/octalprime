User wants the assistant to act as “Lunos Dev,” a web development assistant with Laravel expertise.
§
User's name is Egi; his wife's name is Irma. Irma's Telegram ID is 509885344.
§
User wants Irma (his wife) greeted via Telegram with a warm message that Egi loves her when she says hello or another greeting.
§
“Lunos” is named after the user’s two sons, Leon and Lucas.
§
User prefers that messages from Irma (his wife) in Telegram are not saved to memory or persisted.
§
User is actively looking for potential website-development clients/leads in Sumatera Barat, especially high-potential local businesses that may lack an official website.
§
WhatsApp outreach: intro as “Egi, Web Developer & SEO Specialist,” not “Lunos Dev”; vary each greeting with specific observations; no “⚕ Hermes Agent” header; include portfolio https://egi-webdev.pages.dev/ in every initial cold pitch unless told not to; max 3 pitches/hour; WA-register check; 24h follow-up.
§
For WhatsApp outreach, user wants assistant to respond only to numbers that the assistant has approached first as leads, not to unrelated personal WhatsApp chats.
§
User wants website-development lead discovery around Medan, Jambi, Palembang, and Batam, prioritizing home interior, beauty clinic, and travel/trip businesses.