# Restore Hermes backup

On a new VPS after installing Hermes:

```bash
cd /
tar -xzf /path/to/hermes-backup-YYYYMMDDTHHMMSSZ.tar.gz
# If gateway is running, restart it after restore:
hermes gateway restart
```

If you only want memory/skills/sessions without credentials, copy only:

```bash
cp -a /root/.hermes/skills ~/.hermes/
cp -a /root/.hermes/memories ~/.hermes/
cp -a /root/.hermes/sessions ~/.hermes/
cp -a /root/.hermes/state.db* ~/.hermes/
cp -a /root/.hermes/cron ~/.hermes/
cp -a /root/.hermes/scripts ~/.hermes/
```

Keep `auth.json` and `.env` secure; they may contain tokens/secrets depending on provider setup.
